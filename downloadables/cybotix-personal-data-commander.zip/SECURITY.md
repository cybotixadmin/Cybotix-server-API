# Security Policy

We have to have one of these, so let's get started.

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| 0.8.0   | baseline |

## Reporting a Vulnerability

The product has not had  a proper security review yet. There are a number of issues outstading, 
as is to be expected in a product this early in development. 

See commens in the code for some of them. There are many more. 
A partial list will be added here later. 

Ammend this file as and when anything new is discovered.

Contact lars.reinertsen@cybotix.no for anything security related